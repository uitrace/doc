# -*- coding: UTF-8 -*-
# 添加用户封装
# from userlib.demo_lib import *
# TODO: write your code

startApp(appName='com.tencent.gamereva', splashActivity='com.tencent.gamereva.UfoLaunchActivity', clearApp=True, clearAccount=False)
# 判断第一屏如果存在跳过就点击
if exists('/text="跳过" && type="android.widget.TextView"', timeOut=20, by=DriverType.UIAUTOMATOR):
    click('/text="跳过" && type="android.widget.TextView"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)

# 等待同意使用弹窗出现， 这个过程中可能出现授权弹框。会被自动点掉
wait('obj_1606466537039.jpg', timeOut = 20)
sleep(2)

# 当存在温馨提示文字时表示同意并使用按钮出现，点击同意
if exists('/text="温馨提示" && type="android.widget.TextView"', timeOut=20, by=DriverType.UIAUTOMATOR):
    click('/text="同意并使用" && type="android.widget.TextView"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
sleep(2)

# 切换到 我的 页签
if exists('/text="我的" && type="android.widget.TextView"', timeOut=20, by=DriverType.UIAUTOMATOR):
    click('/text="我的" && type="android.widget.TextView"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)