# -*- coding: UTF-8 -*-
# 添加用户封装
# from userlib.demo_lib import *
# TODO: write your code

'''WeTest UITrace代码模式演示脚本
项目：铁路12306
项目版本：5.1.2 （版本不同可能流程不同，导致脚本无法成功运行）
说明：脚本主要用于演示WeTest UITrace部分功能，实际编写自动化脚本应根据项目实际情况选用更鲁棒的函数。
在调试时建议先不封装为函数，这样运行时能够看到运行到了哪一步。
'''

def enter():
    '''进入铁路12306，为保证操作流程一致，每次执行会清理APP缓存
    '''
    # 启动应用，每次启动会清除缓存（这里使用了启动项目函数）
    startApp(appName='com.MobileTicket', splashActivity='com.alipay.mobile.quinox.LauncherActivity', clearApp=True, clearAccount=False)

    # 15s内如果出现继续使用按钮则点击，类似写法常用于处理偶现页面（这里使用了等待控件及点击控件的函数）
    if exists('/text="继续使用" && type="android.widget.Button"', timeOut = 15, by=DriverType.UIAUTOMATOR):
        click('/text="继续使用" && type="android.widget.Button"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)

    # 这里等待15s是为了让授权弹窗自动处理线程处理授权弹窗
    sleep(15)

    # 这里使用了滑动操作。
    slide((0.85, 0.5), (0.05, 0.5))
    # 操作后常会使用sleep，避免操作太快。如果需要适配测试，sleep时间可以适当延长，以避免低端机处理较慢而操作过快。
    sleep(1)
    slide((0.85, 0.5), (0.05, 0.5))
    sleep(1)

    click('/text="即刻体验" && type="android.widget.Button"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(5)

def ticket():
    '''查询车票操作
    '''
    click('/text="北京" && type="android.widget.TextView"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(2)
    click('/type="android.view.View" && instance="5"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(2)
    # 这里使用了中文输入函数
    inputChineseText(text='深圳')
    sleep(2)
    click('/description="深圳" && type="android.view.View" && instance="0"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(2)
    click('/text="查询车票" && type="android.widget.Button"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(2)
    slideOffset('|resourceid="com.MobileTicket.launcher:id/relativeLayout" && type="android.widget.RelativeLayout"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR)
    sleep(2)

def order():
    '''订单操作
    '''
    # 这里使用了基于图像匹配的点击操作，常用于无法获取到控件的游戏等
    click('obj_1608025507490.jpg', position=(0.444, 0.942, 0.559, 0.995), position_lock=0, animation=0, is_word=0, is_transparent=0, is_highlight=0)
    sleep(2)

    # 这里使用了基于OCR查找函数，如果查找不到再根据控件点击，类似写法常用于多种方式来查找元素，一般情况是先图像无法查找到再直接用相对坐标操作
    btn = find(locator="店", by=DriverType.OCR)
    if btn:
        print("ocr click")
        click(locator=btn)
    else:
        print("ctrl click")
        click('/description="酒店订单 " && type="android.view.View"', xOffset=0, yOffset=0, by=DriverType.UIAUTOMATOR, timeOut=20)
    sleep(2)

    # 这里使用了adb shell的输入函数，此处是进行了3次返回操作
    for i in range(3):
        shell("input keyevent 4")
        sleep(1)


enter()
ticket()
order()
