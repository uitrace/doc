# -*- coding: UTF-8 -*-
from runner.extapi import *
# 添加用户封装
# from demo_lib import *
# TODO: write your code

# 自定义的场景操作
def my_click_image(*args, **kwargs):
    """
    这里填写函数定义
    """
    #TODO: 这里编写具体代码
    
    click('obj_1607077754815.jpg', position=(0.362, 0.338, 0.635, 0.68), position_lock=0, animation=0, is_word=0, is_transparent=0, is_highlight=0)